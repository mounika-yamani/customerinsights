# Customer Insights Dashboard

Below are the screenshots of the dashboard that i have created. 

![alt text](https://github.com/work-mohit/PowerBIVisualizations/blob/1709e98f91a98874d5493cc21ff6441479adfc6c/Bike%20Buyers/Screenshots/cap4.PNG)

![alt text](https://github.com/work-mohit/PowerBIVisualizations/blob/1709e98f91a98874d5493cc21ff6441479adfc6c/Bike%20Buyers/Screenshots/cap1.PNG)

![alt text](https://github.com/work-mohit/PowerBIVisualizations/blob/1709e98f91a98874d5493cc21ff6441479adfc6c/Bike%20Buyers/Screenshots/cap2.PNG)





![alt text](https://github.com/work-mohit/PowerBIVisualizations/blob/1709e98f91a98874d5493cc21ff6441479adfc6c/Bike%20Buyers/Screenshots/cap3.PNG)
